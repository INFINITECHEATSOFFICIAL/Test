package com.hyper.s;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class LoginActivity extends Activity {
    private VideoView loginVideo;
    private ValueAnimator shineAnimator;
    private static final String OFFLINE_KEY = "HyperS-Elite";
    private static final String TELEGRAM_URL = "https://t.me/XINOXXRE1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        loginVideo = findViewById(R.id.login_video_background);
        setupBackgroundVideo(loginVideo);
        startLoginAnimations();
        try {
            if (getActionBar() != null) getActionBar().hide();
        } catch (Exception ignored) { }

        final EditText keyInput = findViewById(R.id.et_license_key);
        final TextView status = findViewById(R.id.tv_login_status);
        Button login = findViewById(R.id.btn_activate);

        View telegram = findViewById(R.id.ll_telegram);
        if (telegram != null) telegram.setOnClickListener(v -> openTelegram());
        View whatsapp = findViewById(R.id.ll_whatsapp);
        if (whatsapp != null) whatsapp.setVisibility(View.GONE);

        login.setOnClickListener(v -> {
            String entered = keyInput.getText().toString().trim();
            if (entered.isEmpty()) {
                status.setText(getString(R.string.login_empty));
                return;
            }
            if (!OFFLINE_KEY.equalsIgnoreCase(entered)) {
                status.setText(getString(R.string.login_invalid_key));
                Toast.makeText(this, R.string.login_invalid_key, Toast.LENGTH_SHORT).show();
                return;
            }
            status.setText(getString(R.string.login_ok));
            playLoginGreeting();
        });
    }



    private void startLoginAnimations() {
        final TextView title = findViewById(R.id.tv_app_title);
        final Button loginButton = findViewById(R.id.btn_activate);
        if (title != null) {
            title.setAlpha(0f);
            title.setTranslationY(18f);
            title.animate().alpha(1f).translationY(0f).setDuration(650L)
                    .setInterpolator(new DecelerateInterpolator()).start();
            title.post(() -> {
                final float width = Math.max(1f, title.getWidth());
                shineAnimator = ValueAnimator.ofFloat(-0.45f, 1.45f);
                shineAnimator.setDuration(1900L);
                shineAnimator.setStartDelay(500L);
                shineAnimator.setRepeatCount(ValueAnimator.INFINITE);
                shineAnimator.addUpdateListener(a -> {
                    float p = (Float) a.getAnimatedValue();
                    float center = width * p;
                    float band = Math.max(70f, width * 0.28f);
                    title.getPaint().setShader(new LinearGradient(
                            center - band, 0f, center + band, 0f,
                            new int[]{0xFFFFFFFF, 0xFF777777, 0xFFFFFFFF},
                            new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
                    title.invalidate();
                });
                shineAnimator.start();
            });
        }
        if (loginButton != null) {
            loginButton.setAlpha(0f);
            loginButton.setTranslationY(14f);
            loginButton.animate().alpha(1f).translationY(0f).setStartDelay(180L)
                    .setDuration(520L).setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    private void setupBackgroundVideo(VideoView video) {
        if (video == null) return;
        try {
            video.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.hypers_background));
            video.setOnPreparedListener(mp -> {
                mp.setLooping(true);
                mp.setVolume(0.45f, 0.45f);
                video.start();
            });
        } catch (Throwable ignored) { }
    }
    @Override protected void onResume() {
        super.onResume();
        if (loginVideo != null && !loginVideo.isPlaying()) loginVideo.start();
    }
    @Override protected void onPause() {
        if (loginVideo != null) loginVideo.pause();
        super.onPause();
    }
    @Override protected void onDestroy() {
        if (loginVideo != null) loginVideo.stopPlayback();
        super.onDestroy();
    }

    private void playLoginGreeting() {
        try {
            MediaPlayer player = MediaPlayer.create(this, R.raw.hypers_login_voice);
            if (player == null) {
                openMainPage();
                return;
            }
            player.setOnCompletionListener(mp -> {
                mp.release();
                openMainPage();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                mp.release();
                openMainPage();
                return true;
            });
            player.start();
        } catch (Throwable ignored) {
            openMainPage();
        }
    }

    private void openMainPage() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void openTelegram() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_URL)));
        } catch (Throwable ignored) {
            Toast.makeText(this, R.string.login_link_error, Toast.LENGTH_SHORT).show();
        }
    }
}
