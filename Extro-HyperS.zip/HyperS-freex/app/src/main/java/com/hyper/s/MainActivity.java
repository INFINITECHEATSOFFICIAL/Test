package com.hyper.s;

import com.hyper.s.config.Prefs;
import com.hyper.s.config.VpnActions;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.MenuItem;
import android.widget.PopupMenu;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.hyper.s.ui.settings.AppPicker;
import com.hyper.s.ui.settings.AppearanceBroadcaster;
import com.hyper.s.ui.settings.PermissionController;
import com.hyper.s.ui.settings.UiBindings;
import com.hyper.s.tunnel.VpnEngineState;
import com.hyper.s.ui.aim.AimController;
import com.hyper.s.ui.aim.Privilege;

import java.util.Calendar;
import java.util.TimeZone;

public class MainActivity extends Activity {
    private VideoView mainVideo;

    private static final long START_TIMEOUT_MS = 4000L;

    private View btnEngine;
    private ImageView ivEnginePower;
    private TextView tvApp;
    private TextView tvStatus;
    private Button btnShizuku;
    private View dotEngine;
    private View dotApp;

    private View dotStrip;
    private TextView tvStripStatus;
    private TextView btnStripEngine;
    private TextView btnMenu;
    private TextView btnBackHome;
    private boolean engineOn = false;
    private boolean waiting  = false;
    private boolean pendingStartAfterOverlay = false;

    private AppearanceBroadcaster broadcaster;
    private UiBindings uiBindings;
    private PermissionController permissionController;
    private com.hyper.s.ui.settings.Pager pager;
    private AppPicker appPicker;

    private BroadcastReceiver stateReceiver;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable startTimeout = new Runnable() {
        @Override
        public void run() {
            if (waiting) {
                waiting = false;
                VpnEngineState s = PacketVpnService.snapshot();
                setUI(s != null && s.engineRun);
                if (s == null || !s.engineRun) toast("Engine failed to start");
            }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getIntent().getBooleanExtra("nepdon_exit_app", false)) {
            finishAndRemoveTask();
            return;
        }

        if (checkAndShowExpiry()) {
            return;
        }

        setContentView(R.layout.activity_main);
        startDashboardAnimation();


        try {
            if (getActionBar() != null) getActionBar().hide();
        } catch (Exception e) { }

        btnEngine   = findViewById(R.id.btn_engine);
        ivEnginePower = (ImageView) findViewById(R.id.iv_engine_power);
        tvApp       = (TextView) findViewById(R.id.tv_selected_app);
        tvStatus    = (TextView) findViewById(R.id.tv_status);
        dotEngine   = findViewById(R.id.dot_engine);
        dotApp      = findViewById(R.id.dot_app);
        dotStrip      = findViewById(R.id.dot_strip);
        tvStripStatus = (TextView) findViewById(R.id.tv_strip_status);
        btnStripEngine = (TextView) findViewById(R.id.btn_strip_engine);
        btnMenu = (TextView) findViewById(R.id.btn_menu);
        btnBackHome = (TextView) findViewById(R.id.btn_back_home);
        final Button btnShowFloating = (Button) findViewById(R.id.btn_show_floating);

        broadcaster = new AppearanceBroadcaster(this);
        uiBindings = new UiBindings(this, broadcaster);
        permissionController = new PermissionController(this);
        appPicker = new AppPicker(this, new AppPicker.Listener() {
            @Override
            public void onSelectionChanged(int selectedCount) {
                updateAppSummary(selectedCount);
            }
        });

        uiBindings.setupAll();
        permissionController.setup();
        pager = new com.hyper.s.ui.settings.Pager(this);
        pager.show(com.hyper.s.ui.settings.Pager.PAGE_HOME);
        setupHeaderMenu();
        setupCommunityButtons();
        // Do not open the Android VPN consent dialog during startup.
        // It is requested only after the user taps ACTIVATE ENGINE, which
        // avoids OEM-specific crashes while the Activity is still starting.
        setUI(false);
        appPicker.loadApps();
        updateAppSummary(Prefs.getTargetPackages(this).size());

        btnEngine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (waiting) return;
                if (!engineOn) {
                    try {
                        if (Prefs.getTargetPackages(MainActivity.this).isEmpty()) {
                            toast(getString(R.string.toast_choose_app));
                            return;
                        }
                        checkVpn();
                    } catch (Throwable t) {
                        waiting = false;
                        handler.removeCallbacks(startTimeout);
                        toast("Engine could not start safely");
                    }
                } else {
                    stopEngine();
                }
            }
        });

        if (btnStripEngine != null) {
            btnStripEngine.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { btnEngine.performClick(); }
            });
        }

        if (btnShowFloating != null) btnShowFloating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!appPicker.isLoaded()) {
                    toast(getString(R.string.checking));
                    return;
                }
                appPicker.show();
            }
        });

        try {
            AimController.init();
        } catch (Throwable ignored) {
            // Aim/Shizuku is optional; it must never prevent the dashboard from opening.
        }
        btnShizuku = (Button) findViewById(R.id.btn_shizuku);
        if (btnShizuku != null) btnShizuku.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onShizukuButton();
            }
        });
        updateShizukuButton();

        registerStateReceiver();
    }

    private void startDashboardAnimation() {
        View home = findViewById(R.id.page_home);
        if (home != null) {
            home.setAlpha(0f);
            home.setTranslationY(26f);
            home.animate().alpha(1f).translationY(0f).setDuration(700L)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
        View engine = findViewById(R.id.btn_engine);
        if (engine != null) {
            engine.setScaleX(0.96f);
            engine.setScaleY(0.96f);
            engine.animate().scaleX(1f).scaleY(1f).setStartDelay(180L)
                    .setDuration(520L).setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    private boolean checkAndShowExpiry() {
        // Expire at noon on 18 Nov 2026 in India and at noon UTC globally.
        Calendar indiaExpiry = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"));
        indiaExpiry.clear();
        indiaExpiry.set(2026, Calendar.NOVEMBER, 18, 12, 0, 0);

        Calendar globalExpiry = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        globalExpiry.clear();
        globalExpiry.set(2026, Calendar.NOVEMBER, 18, 12, 0, 0);

        long now = System.currentTimeMillis();
        if (now >= indiaExpiry.getTimeInMillis() || now >= globalExpiry.getTimeInMillis()) {
            Toast.makeText(this, "This Mod Has Expired!", Toast.LENGTH_LONG).show();
            
            new AlertDialog.Builder(this)
                .setTitle(" Mod Expired")
                .setMessage("This mod expired on 18 November 2026 at 12:00 PM India / 12:00 PM UTC. Open the EXPIRY / UPDATES Telegram link for the latest update.")
                .setCancelable(false)
                .setPositiveButton("JOIN", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/XINOXXRE1"));
                            startActivity(i);
                        } catch (Exception ignored) {}
                        finishAffinity();
                    }
                })
                .setNegativeButton("CLOSE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finishAffinity();
                    }
                })
                .show();
            return true;
        }
        return false;
    }

    private void onShizukuButton() {
        int st = Privilege.state(this);
        switch (st) {
            case Privilege.STATE_NOT_INSTALLED:
                toast("Install Shizuku, then return");
                openShizukuInstall();
                break;
            case Privilege.STATE_NOT_RUNNING:
                toast("Start Shizuku via Wireless Debugging, then tap again");
                launchShizuku();
                break;
            case Privilege.STATE_NO_PERMISSION:
                Privilege.requestPermission();
                break;
            case Privilege.STATE_READY:
                toast("Shizuku ready — aim can inject");
                break;
        }
        handler.postDelayed(new Runnable() {
            @Override public void run() { updateShizukuButton(); }
        }, 400L);
    }

    private void updateShizukuButton() {
        if (btnShizuku != null) btnShizuku.setText(Privilege.stateLabel(this));
    }
    private void setupHeaderMenu() {
        if (btnMenu == null) return;
        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                PopupMenu menu = new PopupMenu(MainActivity.this, btnMenu);
                menu.getMenu().add("Controls");
                menu.getMenu().add("Developer info");
                menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override public boolean onMenuItemClick(MenuItem item) {
                        if (pager == null) return false;
                        if ("Developer info".contentEquals(item.getTitle())) {
                            pager.show(com.hyper.s.ui.settings.Pager.PAGE_SYSTEM);
                        } else {
                            pager.show(com.hyper.s.ui.settings.Pager.PAGE_HOME);
                        }
                        return true;
                    }
                });
                menu.show();
            }
        });
    }

    private void setupCommunityButtons() {
        View telegram = findViewById(R.id.btn_join_telegram);
        View whatsapp = findViewById(R.id.btn_join_whatsapp);
        if (telegram != null) {
            telegram.setOnClickListener(v -> openCommunityUrl("https://t.me/XINOXXRE1"));
        }
        if (whatsapp != null) {
            whatsapp.setOnClickListener(v -> openCommunityUrl("https://www.whatsapp.com/channel/"));
        }
    }

    private void openCommunityUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Throwable ignored) {
            toast("Unable to open community link");
        }
    }

    private void openShizukuInstall() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + Privilege.SHIZUKU_PKG)));
        } catch (Throwable t) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://shizuku.rikka.app/download/")));
            } catch (Throwable ignored) {
            }
        }
    }

    private void launchShizuku() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(Privilege.SHIZUKU_PKG);
            if (i != null) startActivity(i);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onBackPressed() {
        if (pager != null && pager.current() != com.hyper.s.ui.settings.Pager.PAGE_HOME) {
            pager.show(com.hyper.s.ui.settings.Pager.PAGE_HOME);
            return;
        }
        super.onBackPressed();
    }


    private void setupBackgroundVideo(VideoView video) {
        if (video == null) return;
        try {
            video.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.hypers_background));
            video.setOnPreparedListener(mp -> {
                mp.setLooping(true);
                mp.setVolume(0.45f, 0.45f);
                video.start();
            });
        } catch (Throwable ignored) { }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("nepdon_exit_app", false)) {
            finishAndRemoveTask();
        }
    }

    @Override
    protected void onPause() {
        if (mainVideo != null) mainVideo.pause();
        super.onPause();
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (mainVideo != null && !mainVideo.isPlaying()) mainVideo.start();

        if (checkAndShowExpiry()) {
            return;
        }

        try {
            if (permissionController != null) permissionController.refresh();
        } catch (Throwable ignored) { }
        try { Privilege.refresh(); } catch (Throwable ignored) { }
        updateShizukuButton();
        VpnEngineState s = null;
        try { s = PacketVpnService.snapshot(); } catch (Throwable ignored) { }
        setUI(s != null && s.engineRun);
        waiting = false;
        handler.removeCallbacks(startTimeout);
    }

    @Override
    protected void onDestroy() {
        if (mainVideo != null) mainVideo.stopPlayback();
        if (appPicker != null) appPicker.cancel();
        handler.removeCallbacks(startTimeout);
        if (stateReceiver != null) {
            try {
                unregisterReceiver(stateReceiver);
            } catch (Exception e) { }
            stateReceiver = null;
        }
        super.onDestroy();
    }

    private void registerStateReceiver() {
        stateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null) return;
                boolean engineRun = intent.getBooleanExtra("engine_run", false);
                if (waiting && engineRun) {
                    waiting = false;
                    handler.removeCallbacks(startTimeout);
                    toast("Engine ON!");
                }
                if (!engineRun && waiting) return;
                setUI(engineRun);
            }
        };
        try {
            IntentFilter filter = new IntentFilter(VpnActions.ACTION_STATE);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(stateReceiver, filter, "com.hyper.s.permission.INTERNAL_BROADCAST", null);
            }
        } catch (Exception e) {
            com.hyper.s.diag.Diag.hit(
                    com.hyper.s.diag.Slot.UI_RECEIVER_REGISTER_FAILED);
        }
    }

    private void updateAppSummary(int count) {
        if (count <= 0) {
            if (tvApp == null) return;
            tvApp.setText(getString(R.string.no_apps_selected));
            if (dotApp != null) dotApp.setBackgroundResource(R.drawable.dot_off);
        } else {
            java.util.Set<String> pkgs = Prefs.getTargetPackages(this);
            String label = null;
            if (pkgs.size() == 1) {
                String pkg = pkgs.iterator().next();
                try {
                    label = getPackageManager().getApplicationLabel(
                            getPackageManager().getApplicationInfo(pkg, 0)).toString();
                } catch (Throwable t) {
                    label = pkg;
                }
            }
            tvApp.setText(label != null ? label
                    : getString(R.string.selected_apps_count, count));
            if (dotApp != null) dotApp.setBackgroundResource(R.drawable.dot_on);
        }
    }

    private void setUI(boolean on) {
        engineOn = on;
        if (btnEngine == null || tvStatus == null) return;
        if (dotEngine != null)
            dotEngine.setBackgroundResource(on ? R.drawable.dot_on : R.drawable.dot_off);
        TextView engineLabel = (TextView) findViewById(R.id.tv_engine_label);
        if (engineLabel != null) {
            engineLabel.setText(getString(on ? R.string.deactivate_engine
                                             : R.string.activate_engine));
            engineLabel.setTextColor(getResources().getColor(R.color.nv_on_brand));
        }
        if (dotStrip != null) {
            dotStrip.setBackgroundResource(on ? R.drawable.dot_on : R.drawable.dot_off);
        }
        if (tvStripStatus != null) {
            tvStripStatus.setText(getString(on ? R.string.engine_status_connected
                                               : R.string.engine_status_disconnected));
        }
        if (btnStripEngine != null) {
            btnStripEngine.setText(getString(on ? R.string.nv_stop : R.string.nv_start));
            btnStripEngine.setBackgroundResource(
                    on ? R.drawable.nv_btn_secondary : R.drawable.nv_btn_primary);
            btnStripEngine.setTextColor(getResources().getColor(
                    on ? R.color.nv_text : R.color.nv_on_brand));
        }
        if (on) {
            btnEngine.setBackgroundResource(R.drawable.bg_power_circle_on);
            if (ivEnginePower != null)
                ivEnginePower.setColorFilter(getResources().getColor(R.color.nv_on_brand));
            tvStatus.setText(getString(R.string.engine_status_connected));
            tvStatus.setTextColor(getResources().getColor(R.color.nv_on_brand));
        } else {
            btnEngine.setBackgroundResource(R.drawable.bg_power_circle);
            if (ivEnginePower != null)
                ivEnginePower.setColorFilter(getResources().getColor(R.color.nv_on_brand));
            tvStatus.setText(getString(R.string.engine_status_disconnected));
            tvStatus.setTextColor(getResources().getColor(R.color.nv_on_brand));
        }
    }

    private void checkVpn() {
        // The ESP/line/radar renderer needs Android's draw-over-other-apps
        // permission. Ask for it before VPN consent so the user gets a clear,
        // deterministic setup flow and no silent overlay failure.
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            pendingStartAfterOverlay = true;
            try {
                Intent overlay = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(overlay, PermissionController.REQ_OVERLAY_GRANT);
                toast("Allow display over other apps, then return here");
            } catch (Throwable first) {
                try {
                    startActivityForResult(
                            new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION),
                            PermissionController.REQ_OVERLAY_GRANT);
                } catch (Throwable ignored) {
                    pendingStartAfterOverlay = false;
                    toast("Overlay permission settings unavailable");
                }
            }
            return;
        }
        // Never open VPN consent for an empty or invalid target scope.
        if (Prefs.getTargetPackages(this).isEmpty()) {
            toast(getString(R.string.toast_choose_app));
            return;
        }
        // The only entry point for VPN consent. Keep the whole flow guarded
        // because vendor VPN settings activities are not consistent.
        waiting = true;
        handler.postDelayed(startTimeout, START_TIMEOUT_MS);
        try {
            Intent vpnIntent = VpnService.prepare(this);
            if (vpnIntent != null) {
                startActivityForResult(vpnIntent, PermissionController.REQ_VPN);
            } else {
                startEngine();
            }
        } catch (Exception e) {
            waiting = false;
            setUI(false);
            toast("VPN: " + e.getMessage());
        }
    }

    private void startEngine() {
        if (Prefs.getTargetPackages(this).isEmpty()) {
            waiting = false;
            handler.removeCallbacks(startTimeout);
            toast(getString(R.string.toast_choose_app));
            return;
        }
        VpnEngineState s = null;
        try { s = PacketVpnService.snapshot(); } catch (Throwable ignored) { }
        if (s != null && s.engineRun) {
            waiting = false;
            setUI(true);
            toast("Engine already running");
            return;
        }
        try {
            Intent i = new Intent(this, PacketVpnService.class);
            i.setAction(VpnActions.ACTION_SET_APP);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }
            // Start the renderer over the game; dashboard-only mode hides all
            // in-game buttons and panels while ESP/aim remain active.
            try {
                Intent overlay = new Intent(this, FloatingOverlayService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(overlay);
                else startService(overlay);
            } catch (Throwable ignored) { }
        } catch (Throwable e) {
            waiting = false;
            setUI(false);
            toast("XM: " + e.getMessage());
        }
    }

    private void stopEngine() {
        waiting = false;
        handler.removeCallbacks(startTimeout);
        try {
            Intent i = new Intent(this, PacketVpnService.class);
            i.setAction(VpnActions.ACTION_STOP);
            startService(i);
            // Engine OFF also removes every floating button, panel, banner,
            // and ESP overlay by stopping the overlay service itself.
            try {
                stopService(new Intent(this, FloatingOverlayService.class));
            } catch (Throwable ignored) { }
            setUI(false);
            toast("Engine OFF");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PermissionController.REQ_OVERLAY_GRANT) {
            if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
                if (pendingStartAfterOverlay) {
                    pendingStartAfterOverlay = false;
                    checkVpn();
                }
            } else {
                pendingStartAfterOverlay = false;
                toast("Overlay permission is required for ESP, line and radar");
            }
            return;
        }
        if (requestCode == PermissionController.REQ_VPN) {
            try {
                if (permissionController != null) permissionController.refresh();
            } catch (Throwable ignored) { }
            if (resultCode == RESULT_OK) {
                if (!Prefs.getTargetPackages(this).isEmpty()) startEngine();
                else {
                    waiting = false;
                    handler.removeCallbacks(startTimeout);
                    toast(getString(R.string.toast_choose_app));
                }
            } else {
                waiting = false;
                handler.removeCallbacks(startTimeout);
                setUI(false);
                toast("VPN Permission denied!");
            }
        } else if (requestCode == PermissionController.REQ_VPN_GRANT) {
            permissionController.refresh();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        permissionController.refresh();
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
